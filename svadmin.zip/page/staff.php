<?php 
class page_staff extends xavoc_acl\page_user_management{
	function init(){
		parent::init();

		
		
	}
}