<?php
class page_reports_mrkt extends Page{
	function init(){
		parent::init();
		
	}
}