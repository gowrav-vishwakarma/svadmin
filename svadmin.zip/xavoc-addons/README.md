xavoc-addons
============


add the following code in your frontend class to enjoy further xavoc-addons for agile

$this->addLocation('.',array(
            "addons"=>'xavoc-addons'
            ));

