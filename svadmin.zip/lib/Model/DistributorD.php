<?php

class Model_DistributorD extends Model_Distributor {}