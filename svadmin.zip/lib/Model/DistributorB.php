<?php

class Model_DistributorB extends Model_Distributor {}